import {calculateAutomatic, logText} from './core.js';
const $ = id => document.getElementById(id);
const demo = new URLSearchParams(location.search).get('demo') === '1';
let collapsed = false;
let running = false;
let latest = '';
async function request(command, payload) {
  if (demo) return parent.JdlExpenseAdapter.run(command, payload);
  return chrome.runtime.sendMessage({channel: 'jdl-panel', command, payload});
}
$('collapse').addEventListener('click', async () => {
  collapsed = !collapsed;
  $('body').hidden = collapsed;
  $('collapse').textContent = collapsed ? '展开' : '收起';
  $('collapse').setAttribute('aria-expanded', String(!collapsed));
  if (demo) parent.document.getElementById('jdl-expense-panel').style.height = collapsed ? '58px' : '620px';
  else {
    try { await chrome.runtime.sendMessage({channel: 'jdl-panel', command: 'collapse', collapsed}); }
    catch { $('body').hidden = false; collapsed = false; $('collapse').textContent = '收起'; }
  }
});
$('generate').addEventListener('click', async () => {
  if (running) return;
  running = true; $('generate').disabled = true; $('outcome').hidden = true;
  $('body').setAttribute('aria-busy', 'true');
  $('pending').replaceChildren();
  let result;
  const pending = [];
  try {
    $('status').textContent = '正在读取全部发票…';
    const read = await request('read');
    if (!read.ok) throw new Error(read.error);
    result = calculateAutomatic(read.snapshot);
    pending.push(...result.errors, ...result.warnings);
    if (!result.ready) throw new Error('没有可填写的有效发票，原费用事项未修改。');
    $('status').textContent = `正在填写 ${result.groups.length} 个费用分组…`;
    const reply = await request('automatic', result);
    if (!reply.ok) throw new Error(reply.error);
    pending.push(...reply.pending);
    result.events.push({at: new Date().toISOString(), message: reply.message}, ...reply.pending.map(message => ({at: new Date().toISOString(), message})));
    $('status').textContent = reply.message;
  } catch (error) {
    $('status').textContent = `操作未全部完成：${error.message}`;
    pending.push(error.message);
    if (result) result.events.push({at: new Date().toISOString(), message: `操作未全部完成：${error.message}`});
  } finally {
    for (const text of [...new Set(pending)]) { const item = document.createElement('li'); item.textContent = text; $('pending').append(item); }
    if (!pending.length) { const item = document.createElement('li'); item.textContent = '无待补或跳过项。'; $('pending').append(item); }
    latest = result ? logText(result) : `报销事项助手\n${new Date().toLocaleString('zh-CN', {timeZone: 'Asia/Shanghai'})}\n${$('status').textContent}`;
    $('log').textContent = latest; $('outcome').hidden = false;
    if (!demo) {
      try {
        const stored = await chrome.storage.local.get('expenseLogs');
        const entry = {id: result?.id || crypto.randomUUID(), at: result?.calculatedAt || new Date().toISOString(), text: latest, count: result?.sourceCount || 0};
        await chrome.storage.local.set({expenseLogs: [entry, ...(stored.expenseLogs || [])].slice(0, 20)});
      } catch { $('status').textContent += ' 本机日志保存失败，请下载日志。'; }
    }
    running = false; $('generate').disabled = false; $('body').setAttribute('aria-busy', 'false');
  }
});
$('download').addEventListener('click', () => {
  const url = URL.createObjectURL(new Blob(['\uFEFF', latest], {type: 'text/plain;charset=utf-8'}));
  const link = document.createElement('a'); link.href = url; link.download = `报销日志-${Date.now()}.txt`; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
