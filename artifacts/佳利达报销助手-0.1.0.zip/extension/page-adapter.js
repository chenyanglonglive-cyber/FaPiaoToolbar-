/* Runs only when the user invokes the extension. Never saves or submits a workflow. */
(() => {
  if (window.JdlExpenseAdapter?.version === '0.1.0') return;
  const TARGET = {
    smallCategory: ['fyxl1', 'field21331'], departure: ['cfdd', 'field21313'],
    arrival: ['dddd', 'field21314'], days: ['tlts', 'field21315'],
    category: ['fymx', 'field21320'], property: ['fpzx', 'field21332'],
    rate: ['sl', 'field21323'], amount: ['bxje', 'field21319'], tax: ['se', 'field21324'],
    department: ['jzbm', 'field21326'], costCenter: ['cbzx', 'field21325']
  };
  const LABELS = {交通: '交通费', 住宿: '住宿费', 餐费: '餐费', 其他: '其他费用'};
  const owned = new Map();
  let ownershipContext = '';
  let busy = false;
  let lastUndo = null;
  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const clean = value => String(value ?? '').replace(/\s/g, '').trim();
  const visible = element => !!element && element.getClientRects().length > 0;

  function api() {
    const form = window.WfForm;
    if (!form || typeof form.getFieldValue !== 'function') throw new Error('请等待差旅报销表加载完成后重试。');
    const test = (window.location.hostname === '127.0.0.1' && /^\/(?:extension\/)?demo\//.test(window.location.pathname)) ||
      (window.location.protocol === 'chrome-extension:' && window.location.pathname === '/demo/form.html');
    if (!test && (window.location.hostname !== 'crm.jd-link.com' || window.location.port !== '8888')) throw new Error('仅支持指定的佳利达报销系统。');
    const workflow = form.getBaseInfo?.().workflowid || new URLSearchParams(window.location.hash.split('?')[1] || '').get('workflowid');
    if (String(workflow) !== '230') throw new Error('当前页面不是差旅费报销单（流程 230）。');
    return form;
  }

  function context(form) {
    const base = form.getBaseInfo?.() || {};
    return JSON.stringify({workflow: '230', request: String(base.requestid || new URLSearchParams(location.hash.split('?')[1] || '').get('requestid') || 'new'),
      path: location.pathname, session: String(base.f_weaver_belongto_userid || base.userid || '')});
  }

  function fieldRoot(mark) { return document.querySelector(`[data-fieldmark="${mark}"]`); }
  function display(mark) {
    const root = fieldRoot(mark);
    if (!root) return '';
    const selected = root.querySelector('.ant-select-selection-selected-value, .child-item, .ant-select-selection__choice__content');
    if (selected) return (selected.getAttribute('title') || selected.textContent || '').trim();
    const select = root.querySelector('select');
    if (select) return select.selectedOptions[0]?.textContent?.trim() || '';
    const span = document.getElementById(`${mark}span`);
    return (span?.textContent || root.textContent || '').replace(/\*/g, '').trim();
  }

  function indexes(form, detail) {
    const text = String(form.getDetailAllRowIndexStr(detail) || '');
    if (!text) return [];
    const values = text.split(',');
    if (values.some(value => !/^\d+$/.test(value))) throw new Error(`${detail} 的明细行编号无效。`);
    return values;
  }

  function tableFor(required) {
    const candidates = Array.from(document.querySelectorAll('table')).filter(table => {
      return Array.from(table.rows).some(row => row.closest('table') === table && required.every(label => Array.from(row.cells).some(cell => clean(cell.textContent) === label)));
    });
    return candidates.find(table => table.classList.contains('excelDetailTable')) || candidates.at(-1);
  }

  function tableSchema(table, labels) {
    if (!table) throw new Error(`找不到${labels[0]}所在表格。`);
    const header = Array.from(table.rows).find(row => labels.every(label => Array.from(row.cells).some(cell => clean(cell.textContent) === label)));
    const sample = Array.from(table.querySelectorAll('tr[data-rowindex]')).find(row => row.closest('table') === table);
    const columns = {};
    for (const label of labels) {
      const index = Array.from(header.cells).findIndex(cell => clean(cell.textContent) === label);
      const cell = sample?.cells[index];
      const mark = cell?.querySelector('[data-fieldmark]')?.getAttribute('data-fieldmark');
      columns[label] = {index, field: mark?.replace(/_\d+$/, '') || ''};
    }
    const detail = header.cells[0]?.className.match(/\bdetail_(\d+)_/)?.[1] || table.querySelector('[data-cellmark]')?.getAttribute('data-cellmark')?.match(/^detail_(\d+)_/)?.[1];
    if (!detail) throw new Error('无法识别发票明细表，请检查页面是否为原报销表。');
    return {table, detail: `detail_${detail}`, columns};
  }

  function readTable(form, labels) {
    const schema = tableSchema(tableFor(labels), labels);
    const all = indexes(form, schema.detail);
    const rows = all.map(row => {
      const domRow = schema.table.querySelector(`tr[data-rowindex="${row}"]`);
      const values = {row};
      for (const label of labels) {
        const column = schema.columns[label];
        const mark = column.field ? `${column.field}_${row}` : domRow?.cells[column.index]?.querySelector('[data-fieldmark]')?.getAttribute('data-fieldmark');
        if (!mark) throw new Error(`无法读取第 ${row} 行的${label}，请展开表格后重试。`);
        const raw = String(form.getFieldValue(mark) ?? '');
        const shown = display(mark);
        values[label] = (label === '发票税率' || label === '发票类型') ? (shown || raw) : raw;
      }
      return values;
    });
    return rows;
  }

  function targetFields(form) {
    const fields = {};
    for (const [key, [name, fallback]] of Object.entries(TARGET)) {
      const mark = form.convertFieldNameToId?.(name, 'detail_1');
      fields[key] = /^field\d+$/.test(mark || '') ? mark : fallback;
      const actual = document.querySelector(`[data-fieldname="${name}"][data-fieldmark]`);
      if (actual) fields[key] = actual.getAttribute('data-fieldmark').replace(/_\d+$/, '');
    }
    if (!tableFor(['费用明细', '发票属性', '报销金额'])) throw new Error('未找到费用事项表。');
    return fields;
  }

  // Read only the mounted field's choices. Values are never inferred from option order.
  function choices(mark) {
    const root = fieldRoot(mark);
    if (!root) return [];
    const found = new Map();
    const put = (value, label) => {
      if (value == null || typeof value === 'object' || !String(label || '').trim()) return;
      found.set(`${String(value)}|${String(label)}`, {value: String(value), label: String(label).trim()});
    };
    const textOf = value => {
      if (typeof value === 'string' || typeof value === 'number') return String(value);
      if (Array.isArray(value)) return value.map(textOf).join('');
      if (value?.props) return textOf(value.props.children);
      return '';
    };
    const visited = new WeakSet();
    const walk = (value, depth = 0, optionList = false) => {
      if (!value || typeof value !== 'object' || depth > 10 || visited.has(value)) return;
      visited.add(value);
      if (Array.isArray(value)) { value.forEach(item => walk(item, depth + 1, optionList)); return; }
      if (optionList) put(value.value ?? value.id ?? value.key, value.label ?? value.name ?? value.showname ?? textOf(value.children));
      if (value.props) {
        put(value.props.value, value.props.label ?? value.props.title ?? textOf(value.props.children));
        walk(value.props, depth + 1);
      }
      for (const key of ['options', 'datas', 'data', 'items', 'children', 'condition', 'browserCondition']) {
        if (value[key]) walk(value[key], depth + 1, ['options', 'datas', 'data', 'items'].includes(key));
      }
    };
    root.querySelectorAll('select option').forEach(option => put(option.value, option.textContent));
    for (const element of [root, ...root.querySelectorAll('*')]) {
      for (const key of Object.keys(element)) {
        if (/^__react(?:Props|EventHandlers)\$/.test(key)) walk(element[key]);
        if (/^__react(?:Fiber|InternalInstance)\$/.test(key)) {
          let fiber = element[key];
          for (let depth = 0; fiber && depth < 10; depth++, fiber = fiber.return) {
            walk(fiber.memoizedProps);
            if (fiber.stateNode === root) break;
          }
        }
      }
    }
    return [...found.values()];
  }

  function normalizeLabel(value) { return clean(value).replace(/市$/, ''); }
  function matchChoice(mark, labels) {
    const hits = choices(mark).filter(option => labels.some(label => normalizeLabel(option.label) === normalizeLabel(label)));
    const unique = [...new Map(hits.map(option => [option.value, option])).values()];
    if (unique.length > 1) throw new Error(`“${labels[0]}”有多个系统选项，不能自动确定。`);
    return unique[0];
  }

  async function waitUntil(fn, label, timeout = 4000) {
    const until = Date.now() + timeout;
    do { const value = fn(); if (value) return value; await sleep(100); } while (Date.now() < until);
    throw new Error(`${label}，请检查原页面后重试。`);
  }

  function valueInfo(form, mark, browser = false) {
    const value = String(form.getFieldValue(mark) || '');
    if (!browser || !value) return {value};
    const label = display(mark);
    return {value, specialobj: [{id: value, name: label}]};
  }

  function assertEditable(form, mark) {
    if (typeof form.getFieldCurViewAttr === 'function' && ![2, 3].includes(Number(form.getFieldCurViewAttr(mark)))) throw new Error(`字段 ${mark} 当前不可填写。`);
  }

  function setValue(form, mark, info) {
    assertEditable(form, mark);
    form.changeFieldValue(mark, info);
  }

  async function selectLabel(form, mark, labels, browser = false) {
    const choice = matchChoice(mark, labels);
    if (choice) {
      setValue(form, mark, browser ? {value: choice.value, specialobj: [{id: choice.value, name: choice.label}]} : {value: choice.value});
      await waitUntil(() => String(form.getFieldValue(mark)) === choice.value, `${labels[0]}未被系统接受`);
      return;
    }
    // A previously selected browser value provides an authoritative code/name pair.
    const field = mark.replace(/_\d+$/, '');
    if (browser) {
      for (const row of indexes(form, 'detail_1')) {
        const other = `${field}_${row}`;
        const value = String(form.getFieldValue(other) || '');
        if (value && labels.some(label => normalizeLabel(display(other)) === normalizeLabel(label))) {
          setValue(form, mark, {value, specialobj: [{id: value, name: display(other)}]});
          return;
        }
      }
    }
    // Fall back to the system's own dropdown/typeahead; never guess an internal ID.
    const root = fieldRoot(mark);
    const combo = root?.querySelector('[role="combobox"]');
    if (!root || !combo) throw new Error(`无法找到“${labels[0]}”的系统选项。`);
    assertEditable(form, mark);
    combo.click();
    const input = root.querySelector('input.ant-select-search__field, input[type="text"]');
    if (input && browser) {
      input.focus();
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, labels[0]);
      input.dispatchEvent(new Event('input', {bubbles: true}));
      input.dispatchEvent(new Event('change', {bubbles: true}));
    }
    const option = await waitUntil(() => {
      const candidates = Array.from(document.querySelectorAll('.ant-select-dropdown-menu-item, .wea-associative-search-data li, .wea-associative-search-data [title], .wea-city-picker-modal [title]'));
      const matching = candidates.filter(element => visible(element) && labels.some(label => normalizeLabel(element.getAttribute('title') || element.textContent) === normalizeLabel(label)));
      if (matching.length === 1) return matching[0];
      return null;
    }, `找不到“${labels[0]}”的唯一候选项；可先在原页面选好该字段再重新计算`);
    option.click();
    await waitUntil(() => String(form.getFieldValue(mark) || '') && labels.some(label => normalizeLabel(display(mark)) === normalizeLabel(label)), `“${labels[0]}”未被系统接受`);
  }

  function snapshot() {
    const form = api();
    const currentContext = context(form);
    if (ownershipContext !== currentContext) { owned.clear(); lastUndo = null; ownershipContext = currentContext; }
    const raw = readTable(form, ['发票号码', '发票内容', '发票类型', '发票税率', '发票价税合计', '发票未税金额', '发票税额']);
    const applications = readTable(form, ['费用说明']);
    const daysField = document.querySelector('[data-fieldname="ccts"]')?.getAttribute('data-fieldmark') || 'field21403';
    const fields = targetFields(form);
    const existing = indexes(form, 'detail_1').map(row => ({row, owned: owned.has(row),
      values: Object.fromEntries(Object.entries(fields).map(([key, field]) => [key, String(form.getFieldValue(`${field}_${row}`) || '')]))}));
    return {context: currentContext, days: String(form.getFieldValue(daysField) || ''), descriptions: applications.map(row => row['费用说明']),
      invoices: raw.map(row => ({row: row.row, number: row['发票号码'], content: row['发票内容'], type: row['发票类型'], rate: row['发票税率'], amount: row['发票价税合计'], net: row['发票未税金额'], tax: row['发票税额']})),
      existing, fields, canUndo: !!lastUndo};
  }

  function signature(snapshot) {
    return JSON.stringify({context: snapshot.context || '', days: String(snapshot.days ?? ''), descriptions: snapshot.descriptions || [],
      invoices: snapshot.invoices.map(invoice => ({row: String(invoice.row), number: String(invoice.number), content: String(invoice.content), type: String(invoice.type), rate: String(invoice.rate), amount: String(invoice.amount), tax: String(invoice.tax), net: String(invoice.net ?? '')}))});
  }

  function fieldsUnchanged(form, row, values, fields) {
    return Object.entries(values).every(([key, value]) => String(form.getFieldValue(`${fields[key]}_${row}`) || '') === value);
  }

  function validateAmounts(plan, before) {
    const cents = text => {
      const match = /^(-?)(\d+)(?:\.(\d{1,2}))?$/.exec(String(text).normalize('NFKC').trim().replace(/^[¥￥]\s*/, '').replace(/\s*元$/, '').replace(/,/g, ''));
      if (!match) throw new Error('原发票金额无效，请重新计算。');
      const value = Number(match[2]) * 100 + Number((match[3] || '').padEnd(2, '0'));
      if (!Number.isSafeInteger(value)) throw new Error('金额超出可精确计算范围。');
      return match[1] ? -value : value;
    };
    const source = new Map(before.invoices.map(invoice => [String(invoice.row), invoice]));
    const used = new Set();
    const keys = new Set();
    for (const group of plan.groups) {
      if (group.key !== `${group.category}|${group.property}|${group.rate}` || keys.has(group.key)) throw new Error('费用事项分组重复或无效，请重新计算。');
      keys.add(group.key);
      let amount = 0; let tax = 0;
      if (!group.invoices?.length) throw new Error('费用事项没有对应发票。');
      for (const item of group.invoices) {
        const row = String(item.row); const invoice = source.get(row);
        if (!invoice || used.has(row) || String(item.number) !== invoice.number) throw new Error('费用事项有遗漏或重复发票，请重新计算。');
        used.add(row); amount += cents(invoice.amount); tax += cents(invoice.tax);
        if (!Number.isSafeInteger(amount) || !Number.isSafeInteger(tax)) throw new Error('汇总金额超出可精确计算范围。');
      }
      if (amount !== group.amountCents || tax !== group.taxCents) throw new Error('分组金额与票面金额不一致，请重新计算。');
    }
    if (used.size !== source.size) throw new Error('费用事项未包含当前全部发票，请重新计算。');
  }

  async function apply(plan) {
    const form = api();
    if (typeof form.changeFieldValue !== 'function' || typeof form.addDetailRow !== 'function' || typeof form.delDetailRow !== 'function') throw new Error('系统表单接口不完整，暂不能填写。');
    const before = snapshot();
    if (signature(before) !== plan.signature) throw new Error('发票、事前申请或出差天数已变化，请重新读取计算。');
    if (!Array.isArray(plan.groups) || !plan.groups.length || plan.errors?.length || !plan.ready) throw new Error('请先完成计算并处理所有待填写项。');
    if (!/^\d+$/.test(plan.trip?.days || '') || Number(plan.trip.days) <= 0 || !plan.trip.departure || !plan.trip.arrival) throw new Error('城市或停留天数不完整。');
    if (plan.groups.some(group => !LABELS[group.category] || !['普票', '专票'].includes(group.property) || !Number.isSafeInteger(group.amountCents) || !Number.isSafeInteger(group.taxCents))) throw new Error('费用事项数据无效。');
    validateAmounts(plan, before);
    const fields = before.fields;
    const controlled = Object.keys(fields).filter(key => !['department', 'costCenter'].includes(key));
    const templateKeys = new Set(['smallCategory', 'departure', 'arrival', 'department', 'costCenter']);
    const isTemplate = row => Object.entries(row.values).every(([key, value]) => templateKeys.has(key) || value === '');
    const manual = before.existing.filter(row => !row.owned && !isTemplate(row));
    if (manual.length) throw new Error('费用事项已有人工填写内容。为避免重复报销，请先在原页面核对并清理，插件不会覆盖这些行。');
    for (const row of before.existing.filter(row => row.owned)) {
      if (!fieldsUnchanged(form, row.row, owned.get(row.row).values, fields)) throw new Error('你已修改插件生成的事项，请先核对原页面；此次不会覆盖。');
    }
    const obsolete = before.existing.filter(row => row.owned && !plan.groups.some(group => group.key === owned.get(row.row).key));
    if (obsolete.some(row => row.values.department || row.values.costCenter)) throw new Error('需要移除的旧分组已有费用部门或成本中心，请先在原页面处理，避免丢失手填内容。');
    const undo = {context: before.context, fields, before: new Map(), created: [], removed: [], ownership: new Map(owned)};
    const used = new Set();
    const written = [];
    const centsText = value => `${value < 0 ? '-' : ''}${Math.floor(Math.abs(value) / 100)}.${String(Math.abs(value) % 100).padStart(2, '0')}`;
    try {
      for (const group of plan.groups) {
        const matched = before.existing.find(row => row.owned && owned.get(row.row).key === group.key);
        let row = matched?.row;
        if (row == null) row = before.existing.find(candidate => !used.has(candidate.row) && !candidate.owned && isTemplate(candidate))?.row;
        if (row == null) {
          const previous = new Set(indexes(form, 'detail_1'));
          form.addDetailRow('detail_1', {});
          row = await waitUntil(() => indexes(form, 'detail_1').find(index => !previous.has(index)), '新增费用事项失败');
          undo.created.push(row);
          await waitUntil(() => fieldRoot(`${fields.category}_${row}`), '新增费用事项尚未加载');
        } else {
          undo.before.set(row, Object.fromEntries(controlled.map(key => [key, valueInfo(form, `${fields[key]}_${row}`, ['smallCategory', 'departure', 'arrival'].includes(key))])));
        }
        used.add(row);
        const mark = key => `${fields[key]}_${row}`;
        await selectLabel(form, mark('smallCategory'), ['国内差旅'], true);
        await selectLabel(form, mark('departure'), [plan.trip.departure], true);
        await selectLabel(form, mark('arrival'), [plan.trip.arrival], true);
        setValue(form, mark('days'), {value: String(plan.trip.days)});
        await selectLabel(form, mark('category'), [LABELS[group.category]]);
        await selectLabel(form, mark('property'), [group.property]);
        // Rate choices can be dependent on invoice property, so wait for linkage.
        await sleep(200);
        const rateLabels = /^\d/.test(group.rate) ? [group.rate, `${Number(group.rate.replace('%', ''))}.00%`, group.rate.replace('%', '')] : [group.rate];
        await selectLabel(form, mark('rate'), rateLabels);
        setValue(form, mark('amount'), {value: centsText(group.amountCents)});
        setValue(form, mark('tax'), {value: centsText(group.taxCents)});
        await sleep(200);
        if (String(form.getFieldValue(mark('amount'))) !== centsText(group.amountCents) || String(form.getFieldValue(mark('tax'))) !== centsText(group.taxCents)) throw new Error('系统联动改变了金额或税额，已停止填写。');
        written.push({row, key: group.key, values: Object.fromEntries(controlled.map(key => [key, String(form.getFieldValue(mark(key)) || '')]))});
      }
      for (const row of obsolete) {
        const values = Object.fromEntries(controlled.map(key => [key, valueInfo(form, `${fields[key]}_${row}`, ['smallCategory', 'departure', 'arrival'].includes(key))]));
        undo.removed.push({row: row.row, values});
        form.delDetailRow('detail_1', row.row);
        await waitUntil(() => !indexes(form, 'detail_1').includes(row.row), '旧分组未能移除');
        owned.delete(row.row);
      }
      for (const row of written) owned.set(row.row, {key: row.key, values: row.values});
      lastUndo = undo;
      return {ok: true, rows: written.map(row => row.row), message: `已填入 ${written.length} 条费用事项；请补充费用部门和成本中心。未保存或提交。`};
    } catch (error) {
      const failures = await restore(form, undo, false);
      owned.clear(); for (const [row, value] of undo.ownership) owned.set(row, value);
      // A partial restoration must be surfaced rather than reported as a clean rollback.
      throw new Error(`${error.message}${failures.length ? `；部分字段未能恢复：${failures.join('；')}，请核对原页面。` : '；本次填写已回退。'}`);
    }
  }

  async function restore(form, undo, userUndo) {
    const failures = [];
    if (userUndo) {
      for (const row of [...undo.created, ...undo.before.keys()]) {
        const entry = owned.get(row);
        if (!entry || !fieldsUnchanged(form, row, entry.values, undo.fields)) throw new Error('生成事项已被手动修改，不能自动撤销；请在原页面核对。');
        if (undo.created.includes(row) && ['department', 'costCenter'].some(key => form.getFieldValue(`${undo.fields[key]}_${row}`))) throw new Error('新事项已有手填部门或成本中心，不能自动删除。');
      }
    }
    for (const row of undo.created) {
      try { if (indexes(form, 'detail_1').includes(row)) { form.delDetailRow('detail_1', row); await waitUntil(() => !indexes(form, 'detail_1').includes(row), '新增行未能移除'); } }
      catch (error) { failures.push(error.message); }
    }
    for (const [row, values] of undo.before) {
      try { for (const [key, info] of Object.entries(values)) form.changeFieldValue(`${undo.fields[key]}_${row}`, info); }
      catch (error) { failures.push(error.message); }
    }
    for (const removed of undo.removed) {
      try {
        const old = new Set(indexes(form, 'detail_1'));
        form.addDetailRow('detail_1', Object.fromEntries(Object.entries(removed.values).map(([key, info]) => [undo.fields[key], info])));
        const newRow = await waitUntil(() => indexes(form, 'detail_1').find(row => !old.has(row)), '旧分组未能恢复');
        const entry = undo.ownership.get(removed.row);
        undo.ownership.delete(removed.row);
        if (entry) undo.ownership.set(newRow, entry);
      } catch (error) { failures.push(error.message); }
    }
    return failures;
  }

  async function undoApply() {
    const form = api();
    if (!lastUndo) throw new Error('本页面没有可撤销的插件填写。');
    if (context(form) !== lastUndo.context) throw new Error('已切换报销单，不能撤销上一个页面的填写。');
    const failures = await restore(form, lastUndo, true);
    if (failures.length) throw new Error(`撤销未完全成功，请核对原页面：${failures.join('；')}`);
    owned.clear(); for (const [row, value] of lastUndo.ownership) owned.set(row, value);
    lastUndo = null;
    return {ok: true, message: '已撤销最近一次插件填写，保留原有内容。'};
  }

  window.JdlExpenseAdapter = {
    version: '0.1.0',
    async run(command, payload) {
      if (busy) return {ok: false, error: '正在处理，请等待本次操作完成。'};
      busy = true;
      try {
        if (command === 'read') return {ok: true, snapshot: snapshot()};
        if (command === 'apply') return await apply(payload);
        if (command === 'undo') return await undoApply();
        return {ok: false, error: '不支持的操作。'};
      } catch (error) { return {ok: false, error: error.message}; }
      finally { busy = false; }
    }
  };
})();
