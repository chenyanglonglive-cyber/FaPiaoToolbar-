document.getElementById('open').addEventListener('click', async () => {
  const status = document.getElementById('popup-status');
  try {
    const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    const url = new URL(tab.url || '');
    if (url.hostname !== 'crm.jd-link.com' || url.port !== '8888' || !url.pathname.startsWith('/spa/workflow/')) throw new Error('请先打开佳利达差旅费报销单，再点击插件。');
    await chrome.tabs.create({url: chrome.runtime.getURL(`dashboard.html?source=${tab.id}`)});
    window.close();
  } catch (error) { status.textContent = error.message; }
});
