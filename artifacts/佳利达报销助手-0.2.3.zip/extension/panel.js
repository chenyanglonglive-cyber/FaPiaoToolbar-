import {calculateAutomatic, expenseLedger, logText, money} from './core.js';
const $ = id => document.getElementById(id);
const demo = new URLSearchParams(location.search).get('demo') === '1';
let collapsed = false;
let running = false;
let latest = '';
function element(tag, text) {
  const node = document.createElement(tag);
  if (text != null) node.textContent = text;
  return node;
}
function renderLedger(result) {
  const container = $('ledger');
  container.replaceChildren();
  if (!result?.groups.length) { container.append(element('p', '无有效费用分组。')); return; }
  for (const group of expenseLedger(result)) {
    const block = element('section'); block.className = 'ledger-group';
    block.append(element('h3', `${group.title} · ${group.category} / ${group.kind} / ${group.property} / ${group.rate}`));
    const status = element('p', `${group.status} · ${group.invoices.length} 张发票${group.reason ? ` · ${group.reason}` : ''}`); status.className = 'ledger-state'; block.append(status);
    const table = element('table'); table.setAttribute('aria-label', `${group.title}对应发票`);
    const head = element('thead'); const header = element('tr');
    for (const title of ['发票号码', '发票内容', '价税合计', '票面税率', '票面税额', '可抵扣税额']) { const cell = element('th', title); cell.scope = 'col'; header.append(cell); }
    head.append(header); table.append(head);
    const body = element('tbody');
    for (const invoice of group.invoices) {
      const row = element('tr');
      for (const value of [invoice.number, invoice.content, invoice.amount, invoice.invoiceRate, invoice.tax, invoice.deductibleTax]) row.append(element('td', value));
      body.append(row);
    }
    table.append(body);
    const foot = element('tfoot'); const total = element('tr'); const label = element('th', '本事项合计'); label.colSpan = 2; label.scope = 'row';
    total.append(label, element('td', money(group.amountCents)), element('td', ''), element('td', money(group.invoiceTaxCents)), element('td', money(group.taxCents))); foot.append(total); table.append(foot);
    block.append(table, element('p', `费用事项未税金额 ${money(group.netCents)} 元。`));
    container.append(block);
  }
}
async function request(command, payload) {
  if (demo) return parent.JdlExpenseAdapter.run(command, payload);
  return chrome.runtime.sendMessage({channel: 'jdl-panel', command, payload});
}
$('collapse').addEventListener('click', async () => {
  collapsed = !collapsed;
  $('body').hidden = collapsed;
  $('collapse').textContent = collapsed ? '展开' : '收起';
  $('collapse').setAttribute('aria-expanded', String(!collapsed));
  if (demo) parent.document.getElementById('jdl-expense-panel').style.height = collapsed ? '58px' : '620px';
  else {
    try { await chrome.runtime.sendMessage({channel: 'jdl-panel', command: 'collapse', collapsed}); }
    catch { $('body').hidden = false; collapsed = false; $('collapse').textContent = '收起'; }
  }
});
$('generate').addEventListener('click', async () => {
  if (running) return;
  running = true; $('generate').disabled = true; $('outcome').hidden = true;
  $('body').setAttribute('aria-busy', 'true');
  $('pending').replaceChildren();
  let result;
  const pending = [];
  try {
    $('status').textContent = '正在读取全部发票…';
    const read = await request('read');
    if (!read.ok) throw new Error(read.error);
    result = calculateAutomatic(read.snapshot);
    pending.push(...result.errors, ...result.warnings);
    if (!result.ready) throw new Error('没有可填写的有效发票，原费用事项未修改。');
    $('status').textContent = `正在填写 ${result.groups.length} 个费用分组…`;
    const reply = await request('automatic', result);
    if (!reply.ok) throw new Error(reply.error);
    result.writeOutcome = {writtenGroups: reply.writtenGroups || [], skippedGroups: reply.skippedGroups || []};
    pending.push(...reply.pending);
    result.events.push({at: new Date().toISOString(), message: reply.message}, ...reply.pending.map(message => ({at: new Date().toISOString(), message})));
    $('status').textContent = reply.message;
  } catch (error) {
    $('status').textContent = `操作未全部完成：${error.message}`;
    pending.push(error.message);
    if (result) result.events.push({at: new Date().toISOString(), message: `操作未全部完成：${error.message}`});
  } finally {
    for (const text of [...new Set(pending)]) { const item = document.createElement('li'); item.textContent = text; $('pending').append(item); }
    if (!pending.length) { const item = document.createElement('li'); item.textContent = '无待补或跳过项。'; $('pending').append(item); }
    latest = result ? logText(result) : `报销事项助手\n${new Date().toLocaleString('zh-CN', {timeZone: 'Asia/Shanghai'})}\n${$('status').textContent}`;
    renderLedger(result);
    $('log').textContent = latest; $('outcome').hidden = false;
    if (!demo) {
      try {
        const stored = await chrome.storage.local.get('expenseLogs');
        const entry = {id: result?.id || crypto.randomUUID(), at: result?.calculatedAt || new Date().toISOString(), text: latest, count: result?.sourceCount || 0};
        await chrome.storage.local.set({expenseLogs: [entry, ...(stored.expenseLogs || [])].slice(0, 20)});
      } catch { $('status').textContent += ' 本机日志保存失败，请下载日志。'; }
    }
    running = false; $('generate').disabled = false; $('body').setAttribute('aria-busy', 'false');
  }
});
$('download').addEventListener('click', () => {
  const url = URL.createObjectURL(new Blob(['\uFEFF', latest], {type: 'text/plain;charset=utf-8'}));
  const link = document.createElement('a'); link.href = url; link.download = `报销日志-${Date.now()}.txt`; link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
});
